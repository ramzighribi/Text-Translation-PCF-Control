var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./PCFTranslationFields/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./PCFTranslationFields/index.ts":
/*!***************************************!*\
  !*** ./PCFTranslationFields/index.ts ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.PCFTranslationFields = void 0;\n\nvar PCFTranslationFields =\n/** @class */\nfunction () {\n  function PCFTranslationFields() {}\n\n  PCFTranslationFields.prototype.init = function (context, notifyOutputChanged, state, container) {\n    var _a;\n\n    this._context = context;\n    this._notifyOutputChanged = notifyOutputChanged;\n    this._container = container;\n    this._translationResult = \"\";\n    this._Selectedlanguage = \"\"; // Add the textbox control, styling and event listener\n\n    this._TextToBeTranslatedElement = document.createElement(\"input\");\n\n    this._TextToBeTranslatedElement.setAttribute(\"type\", \"text\");\n\n    this._TextToBeTranslatedElement.setAttribute(\"class\", \"pcfinputcontrol\"); //this._TextToBeTranslatedElement.addEventListener('change', this.HideTranslatedMessage );\n\n\n    this._TextToBeTranslatedElement.addEventListener(\"change\", this.onChange.bind(this));\n\n    var crmOriginalTextAttribute = (_a = this._context.parameters.TextToTranslate.attributes) === null || _a === void 0 ? void 0 : _a.LogicalName; //@ts-ignore\n\n    this._TextToBeTranslatedElement.value = Xrm.Page.getAttribute(crmOriginalTextAttribute).getValue(); // Add a visual to show the error message when the message is translated\n\n    this._TranslatedTextArea = document.createElement(\"div\");\n\n    this._TranslatedTextArea.setAttribute(\"class\", \"pcferrorcontroldiv\"); //Create The message element formated\n\n\n    var _TranslatedMessageValue = document.createElement(\"label\");\n\n    _TranslatedMessageValue.setAttribute(\"class\", \"pcftranslationcontrollabel\");\n\n    _TranslatedMessageValue.innerText = \"\";\n\n    this._TranslatedTextArea.appendChild(_TranslatedMessageValue);\n\n    this._TranslatedTextArea.style.display = \"none\";\n    this._selectElement = document.createElement(\"select\");\n\n    this._selectElement.setAttribute(\"class\", \"pcfselectcontrol\");\n\n    var languageList = document.createElement(\"option\");\n    var optionList = this._selectElement.options;\n    var options = [{\n      text: 'Select',\n      value: 'var0',\n      selected: true\n    }, {\n      text: 'Ar',\n      value: 'var1'\n    }, {\n      text: 'De',\n      value: 'var2'\n    }, {\n      text: 'Es',\n      value: 'var3'\n    }, {\n      text: 'Fr',\n      value: 'var4'\n    }, {\n      text: 'Zh',\n      value: 'var5'\n    }];\n    options.forEach(function (option) {\n      return optionList.add(new Option(option.text, option.value, option.selected));\n    });\n    var ShowButton = document.createElement(\"button\"); //ShowButton.setAttribute(\"style\", \"background-color:#ffffff\");\n\n    ShowButton.innerHTML = \"︾\";\n    ShowButton.addEventListener(\"click\", this.onButtonClick.bind(this));\n\n    this._selectElement.addEventListener('change', this.onButtonClick.bind(this)); //hide message area\n\n\n    var HideButton = document.createElement(\"button\");\n    HideButton.innerHTML = \"︽\";\n    HideButton.addEventListener(\"click\", this.HideTranslatedMessage.bind(this));\n    this._languages = languageList.value;\n\n    this._container.appendChild(this._TextToBeTranslatedElement);\n\n    this._container.appendChild(this._selectElement); //this._container.appendChild(HideButton);\n\n\n    this._container.appendChild(this._TranslatedTextArea); //@ts-ignore\n\n\n    this._TextToBeTranslatedElement.value == Xrm.Page.getAttribute(crmOriginalTextAttribute).getValue();\n  };\n\n  PCFTranslationFields.prototype.updateView = function (context) {\n    //@ts-ignore\n    this._TextToBeTranslatedElement.value == Xrm.Page.getAttribute(crmOriginalTextAttribute).getValue(); //}\n  };\n\n  PCFTranslationFields.prototype.onChange = function (evt) {\n    var _a;\n\n    var crmOriginalTextAttribute = (_a = this._context.parameters.TextToTranslate.attributes) === null || _a === void 0 ? void 0 : _a.LogicalName; //@ts-ignore\n    //alert(\"CRM field value : \" + Xrm.Page.getAttribute(crmOriginalTextAttribute).getValue());\n    //@ts-ignore\n\n    Xrm.Page.getAttribute(crmOriginalTextAttribute).setValue(this._TextToBeTranslatedElement.value);\n\n    this._notifyOutputChanged();\n  };\n\n  PCFTranslationFields.prototype.onButtonClick = function (event) {\n    this._Selectedlanguage = \"\";\n\n    function Translate(targetLang, text, sourceLang) {\n      if (targetLang === void 0) {\n        targetLang = \"\";\n      }\n\n      if (text === void 0) {\n        text = \"\";\n      }\n\n      if (sourceLang === void 0) {\n        sourceLang = 'auto';\n      }\n\n      var result = \"\";\n      fetch(\"https://translate.googleapis.com/translate_a/single?client=gtx&sl=\" + sourceLang + \"&tl=\" + targetLang + \"&dt=t&q=\" + encodeURI(text)).then(function (res) {\n        if (res.status >= 200 && res.status < 300) {\n          return Promise.resolve(res);\n        } else {\n          return Promise.reject(new Error(res.statusText));\n        }\n      }).then(function (res) {\n        return res.json();\n      }).then(function (data) {\n        result = data[0][0][0];\n        document.getElementsByClassName(\"pcftranslationcontrollabel\")[0].innerHTML = result;\n      }).catch(function (err) {\n        alert(\"Request failed : \" + err);\n      });\n      return result;\n    }\n\n    if (this._TextToBeTranslatedElement.value !== \"\" && this._selectElement.options[this._selectElement.selectedIndex].text !== \"Select\") {\n      this._Selectedlanguage = this._selectElement.options[this._selectElement.selectedIndex].text;\n      this._TextToBeTranslated = this._TextToBeTranslatedElement.value;\n      this._translationResult = Translate(this._Selectedlanguage, this._TextToBeTranslated);\n      this._TranslatedTextArea.style.display = \"block\";\n    } else {\n      if (this._selectElement.options[this._selectElement.selectedIndex].text === \"\" || this._TextToBeTranslatedElement.value === \"\") {\n        document.getElementsByClassName(\"pcftranslationcontrollabel\")[0].innerHTML = \"\";\n        this._TranslatedTextArea.style.display = \"none\";\n      }\n    }\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  PCFTranslationFields.prototype.destroy = function () {};\n\n  PCFTranslationFields.prototype.HideTranslatedMessage = function () {\n    document.getElementsByClassName(\"pcftranslationcontrollabel\")[0].innerHTML = \"\";\n    this._TranslatedTextArea.style.display = \"none\";\n  };\n\n  PCFTranslationFields.prototype.getOutputs = function () {\n    return {//TextToTranslate: this._TextToBeTranslated;\n    };\n  };\n\n  return PCFTranslationFields;\n}();\n\nexports.PCFTranslationFields = PCFTranslationFields;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./PCFTranslationFields/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('PCFTranslationFields.PCFTranslationFields', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.PCFTranslationFields);
} else {
	var PCFTranslationFields = PCFTranslationFields || {};
	PCFTranslationFields.PCFTranslationFields = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.PCFTranslationFields;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}